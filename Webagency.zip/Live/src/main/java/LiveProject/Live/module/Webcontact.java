package LiveProject.Live.module;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Webcontact {

	String name;
	String number;
	@Id
	String email;
	String message;

	public Webcontact(String name, String number, String email, String message) {
		super();
		this.name = name;
		this.number = number;
		this.email = email;
		this.message = message;
	}

	public Webcontact() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Webcontact [name=" + name + ", number=" + number + ", email=" + email + ", message=" + message + "]";
	}

}
