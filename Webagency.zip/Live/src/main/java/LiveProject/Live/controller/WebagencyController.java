package LiveProject.Live.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import LiveProject.Live.module.Webcontact;

@Controller
public class WebagencyController {

	@RequestMapping("web agency")
	public String indexPage() {
		return "index";
	}

	@RequestMapping("about")
	public String aboutPage() {
		return "about";
	}

	@RequestMapping("contact")
	public String contactPage() {
		return "contact";
	}

	@Autowired
	SessionFactory sf;

	@RequestMapping("contactSave")
	public String contactsave(Webcontact contact) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.save(contact);
		tx.commit();
		
		return "contact";
	}

	@RequestMapping("do")
	public String doPage() {
		return "do";
	}

	@RequestMapping("portfolio")
	public String portfolioPage() {
		return "portfolio";
	}

}
